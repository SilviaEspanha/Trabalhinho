      // Import the functions you need from the SDKs you need
      import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
      // TODO: Add SDKs for Firebase products that you want to use
      // https://firebase.google.com/docs/web/setup#available-libraries
    
      // Your web app's Firebase configuration
      const firebaseConfig = {
        apiKey: "AIzaSyB7d2_gDpVAmd9_eJiBm6HvDzENZyZrM7s",
        authDomain: "trabalhinho-43003.firebaseapp.com",
        projectId: "trabalhinho-43003",
        storageBucket: "trabalhinho-43003.appspot.com",
        messagingSenderId: "123911645743",
        appId: "1:123911645743:web:537c7b5a3d943f0a34f4da"
      };
    
      // Initialize Firebase
      const app = initializeApp(firebaseConfig);
